from flask import render_template, redirect, url_for,request, current_app,flash
from flask_login import login_user,current_user,logout_user,login_required
from gonghui.forms import LoginForm,RegisterForm,PasswdResetRequestForm,PasswdResetForm
from gonghui.models.user import User
from gonghui.models.condolence import Condolence
from gonghui.models.account import Account
from gonghui import db
from gonghui.email import send_email

@login_required
def index():
    return render_template('index.html',title='首页')

def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u is None or not u.check_password(form.password.data):
            flash('用户名或密码错误！')
            return redirect(url_for('login'))
        login_user(u,remember=form.remember_me.data)    #此句让系统记住登录者状态
        next_page = request.args.get('next')            #next_page让系统记住使登录后返回之前浏览页面
        if next_page:
            return redirect(next_page)
        return redirect(url_for('index'))
    return render_template('login.html',title="欢迎使用工会财管系统，请先登录",form=form)

def logout():
    logout_user()
    return redirect(url_for('login'))

def manageruser():
    users = User.query.all()
    return render_template('manageruser.html',title="用户管理",users=users)

def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('manageruser'))
    return render_template('register.html',title='增加用户',form=form)


def password_reset_request():
    #if current_user.is_authonticated:
    #    return redirect(url_for('index'))
    form = PasswdResetRequestForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            flash("您将收到一封允许您重置密码的电子邮件。\
                如果你找不到这封邮件，请务必检查您的垃圾邮件！")
            token = user.get_jwt()
            url_password_reset = url_for(
                'password_reset',
                token=token,
                _external=True                    #发送的链接是完整的http链接
            )
            url_password_reset_request = url_for(
                'password_reset_request',
                _external=True
            )
            send_email(
               subject=current_app.config['MAIL_SUBJECT_PASSWORD_RESET'],                    #主题
               recipients=[user.email],                             #接收者
               text_body=render_template(
                   'email/passwd_reset.txt',
                   url_password_reset=url_password_reset,
                   url_password_reset_request=url_password_reset_request
               ),
               html_body=render_template(
                   'email/passwd_reset.html',
                   url_password_reset=url_password_reset,
                   url_password_reset_request=url_password_reset_request
               )
            )
        else:
            raise
        return redirect(url_for('login'))
    return render_template('password_reset_request.html',title='请求重置密码',form=form)

def password_reset(token):
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    user = User.verify_jwt(token)
    if not user:
        return redirect(url_for('login'))
    form = PasswdResetForm()
    if form.validate_on_submit():
        user.set_password(form.password.data)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template(
        'password_reset.html',title='密码重置',form=form
    )

def account():
    return render_template('account.html',title="财务记账")

def condolence():
    return render_template('condolence.html',title="慰问登记")
