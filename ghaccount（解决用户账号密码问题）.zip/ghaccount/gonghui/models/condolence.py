from datetime import datetime
from gonghui import db

class Condolence(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    c_date = db.Column(db.Date)
    c_name = db.Column(db.String(10))
    matters = db.Column(db.String(50))
    c_type = db.Column(db.String(10))
    c_count = db.Column(db.Float(20,2))
    remark = db.Column(db.String(50))

    def __repr__(self):
        return "id={}, c_date={}, c_name={},matters={}, c_type={},c_count={},remark={}".format(
            self.id,self.a_date,self.c_name,self.matters,self.c_type,self.c_count,self.remark
        )
