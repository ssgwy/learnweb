from datetime import datetime
from gonghui import db

class Member_info(db.Model):
    id = db.Column(db.Integer,primary_key=True)    
    info_code = db.Column(db.Integer)
    gender = db.Column(db.String(2))    #性别
    nation = db.Column(db.String(2))    #民族
    political_status = db.Column(db.String(10))    #政治面貌
    native_place = db.Column(db.String(20))    #籍贯
    date_birth = db.Column(db.Date)    #出生日期
    education = db.Column(db.String(10))    #学历
    ID_num = db.Column(db.String(20))    #身份证号
    phone = db.Column(db.String(20))    #联系电话
    email = db.Column(db.String(64))    #联系电话
    personnel_type =  db.Column(db.String(10))    #职工类型
    remark = db.Column(db.String(50))    #备注

    def __repr__(self):
        return "id={}, info_code={}, gender={}, nation={},political_status={},native_place={},date_birth={},education={},ID_num={},phone={},email={},personnel_type={},remark={}".format(
            self.id,self.info_code,self.gender,self.nation,self.political_status,self.native_place,self.date_birth,self.education,self.ID_num,self.phone,self.email,self.personnel_type,self.remark
        )