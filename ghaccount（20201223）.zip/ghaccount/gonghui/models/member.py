from datetime import datetime
from gonghui import db
from gonghui.models.member_info import Member_info

class Member(db.Model):
    id = db.Column(db.Integer,primary_key=True)   
    name = db.Column(db.String(64),index=True)
    salary = db.Column(db.Float)
    membership_fee = db.Column(db.Float)
    date_year = db.Column(db.Integer,index=True)
    date_half_year = db.Column(db.String(6),index=True)   
    info_code = db.Column(db.Integer,db.ForeignKey('member_info.info_code'))

    def __repr__(self):
        return "id={}, name={}, salary={}, menbership_fee={},date_start={},date_end={},info_code={}".format(
            self.id,self.name,self.salary,self.membership_fee,self.date_start,self.date_end,self.info_code
        )