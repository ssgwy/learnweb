from flask import render_template,redirect,url_for,request,abort
from flask_login import login_user,current_user,logout_user,login_required
from twittor.forms import LoginForm,RegisterForm,EditProfileForm
from twittor.models import User,Tweet
from twittor import db

@login_required
def index():
    posts = [
        {
            'author':{'username':'张三'},
            'body':"你好，我是张三！"
        }, 
        {
            'author':{'username':'机器人'},
            'body':"你好，我是机器人！"
        },
    ]
    return render_template('index.html',title="首页",posts=posts)

def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u is None or not u.check_password(form.password.data):
            print('invalid username or password')
            return redirect(url_for('login'))
        login_user(u,remember=form.remember_me.data)
        next_page = request.args.get('next')
        if next_page:
            return redirect(next_page)
        return redirect(url_for('index'))
    return render_template('login.html',title="登录",form=form)

def logout():
    logout_user()
    return redirect(url_for('login'))


def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', title='用户注册', form=form)

@login_required
def user(username):
    u = User.query.filter_by(username=username).first()
    if u is None:
        abort(404)
    posts = [
        {
            'author':{'username':u.username},
            'body':"你好，我是 {}！".format(u.username)
        }, 
        {
            'author':{'username':u.username},
            'body':"你好，我是 {}！".format(u.username)
        }
    ]
    if request.method == 'POST':
        if request.form['request_button'] == '关注':
            current_user.follow(u)
            db.session.commit()
        else:
            current_user.unfollow(u)
            db.session.commit()
    return render_template('user.html',title="个人主页",posts=posts,user=u)

def page_not_found(e):
    return render_template('404.html',title="404"),404

@login_required
def edit_profile():
    form = EditProfileForm()
    #如果存在信息，则显示出来
    if request.method == 'GET':
        form.about_me.data = current_user.about_me
    #保存信息
    if form.validate_on_submit():
        current_user.about_me = form.about_me.data
        db.session.commit()
    #跳转到个人简介页面,url_for()里面填写页面别名
        return redirect(url_for('profile',username=current_user.username))
    return render_template('edit_profile.html',title="编辑个人简介",form=form)
